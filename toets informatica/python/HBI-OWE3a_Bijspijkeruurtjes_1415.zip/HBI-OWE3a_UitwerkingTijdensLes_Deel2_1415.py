import random as rdm
import numpy as np
import matplotlib.pyplot as plt

def main():
    gegevens = maakData()
    maakBarPlot(gegevens)
    maakLinePlot(gegevens)
    maakPolyPlot(gegevens)
    plt.show()

def maakData():
    data1 = [rdm.randint(0,10) for _ in range(10)]
    data2 = [rdm.randint(0,10) for _ in range(10)]
    return data1, data2

def maakBarPlot(data):
    data3 = data[0]
    data4 = data[1]
    ind1 = np.arange(len(data3))
    ind2 = np.arange(len(data4))
    width = 0.8

    #fig, ax = plt.subplots()
    #plt.subplot
    
    #rects1 = ax.bar(ind1, data3, width, color="yellow")
    #rects2 = ax.bar(ind2+width, data4, width, color="purple")
    plt.bar(ind1, data3, width, color="yellow")
    plt.bar(ind2, data4, width, color="purple")
    plt.ylim(-5, 20)

main()
