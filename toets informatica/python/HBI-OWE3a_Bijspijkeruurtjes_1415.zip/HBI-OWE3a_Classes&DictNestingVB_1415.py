# Auteur: Esther Kok
# Datum: 18-03-2015
# Classes en dictionary nesting voorbeeld
# Python 3.4 compatible

# imports
import random as rm
import sys
import re

# Onze betrouwbare main functie
def main():
    seq1 = 'blargdinglolwutomgwtfbbqlmfaoblargdinglolwutomgwtfbbqlmfaoblargdinglolwutomgwtfbbqlmfaoblargdinglolwutomgwtfbbqlmfaoblargdinglolwutomgwtfbbqlmfaoblargdinglolwutomgwtfbbqlmfaoblargdinglolwutomgwtfbbqlmfaoblargdinglolwutomgwtfbbqlmfao'
    seq2 = 'atgatgatgatgatgatgatgatgatgatgatgatgatgatgatgatgatgatgatgatgatg'

    # instance voor seq1
    seqding1 = sequence(seq1)
    splitCodons1 = seqding1.codonSplitter()
    print("Splitted Codons:", splitCodons1)
    match1 = seqding1.regex("a[tg][tg]")
    codonDict = seqding1.setCountCodons()
    print("CodonDict:", codonDict)
    seqding1.getCountCodons("wtf")

    #instance voor seq2
    seqding2 = sequence(seq2)
    match2 = seqding2.regex("a[tg][tg]")
    print(match2)

# een sequentie classe die kan splitten op codons, een regex kan zoeken in de sequentie
# en een genestte dictionary kan maken, en info over opvragen
class sequence:
    def __init__(self, s):
        self.sequence = s
        self.codonList = []

    # recursieve codonsplitter
    # NB, dit is geen mooie codonsplitter, want hij breekt hem vanaf het begin in hapjes
    # terwijl je dit natuurlijk pas vanaf het startcodon wilt doen, maar anders werkt het
    # niet met "blablabla..."
    def codonSplitter(self, sequence = None, codonList = None):
        if sequence is None:
            sequence = self.sequence
        if codonList is None:
            codonList = self.codonList
        if len(sequence) == 0:
            return self.codonList
        else:
            codonList.append(sequence[0:3])
            return self.codonSplitter(sequence[3:], codonList)

    # codon teller die het resultaat in een genestte lijst stopt
    # let op, de nesting is totaal redundant, is slechts ter illustratie
    def setCountCodons(self):
        self.codonDict = {}
        for item in self.codonList:
            number = self.codonList.count(item)
            self.codonDict[item] = {}
            for ding in self.codonList:
                if ding == item:
                    self.codonDict[item][ding] = number
        return self.codonDict

    # en op deze manier kan je resultaten uit je nesting halen
    def getCountCodons(self, codon):
        self.codonlaag1 = self.codonDict[codon]
        self.codonlaag2 = self.codonDict[codon][codon]
        print("laag 1 (self.codonDict[",codon,"]):       ", self.codonlaag1)
        print("laag 2 (self.codonDict[",codon,"][",codon,"]):", self.codonlaag2)
        

    # regex matcher, spreekt redelijk voor zichzelf
    def regex(self, regex):
        match = re.search(regex, self.sequence)
        if match is None:
            self.matches = False
        else:
            self.matches = True
        return self.matches
        
        
# en natuurlijk moeten we onze main() dan ook aanroepen
main()
        
    
