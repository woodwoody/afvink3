#imports
import random

#main
def main():
    uitkomst = vbFunctie()
    andereVbFunctie(uitkomst)

#functies
def vbFunctie():
    cijferlijst = []
    for i in range(0,10):
        cijferlijst.append(random.randint(0,10))
    return cijferlijst
        
def andereVbFunctie(lijst):
    print("Dit is de lijst: " + str(lijst))
    print("Het eerste element uit de lijst is: " + str(lijst[0]))
    print("Het tweede element uit de lijst is: " + str(lijst[1]))
    print("De rest van de lijst is: " + str(lijst[2:]))
    print("Het tweede tot en met het vierde element is: " + str(lijst[1:4]))

    #for cijfer in lijst: 
        #print("Dit zijn de losse cijfers:" + str(cijfer))

    nieuwelijst = vbFunctie()
    print(nieuwelijst)

    for cijferOri in lijst:
        print("Cijfer: " + str(cijferOri))
        if cijferOri == 10:
            print("Je heb een super voldoende")
        elif cijferOri >= 8:
            print("Je hebt een goede voldoende")
        elif cijferOri > 5:
            print("Je hebt een voldoende")
        else:
            print("Je hebt een onvoldoende :(")

        for cijferNew in nieuwelijst:
            print("Het nieuwe cijfer is: " + str(cijferNew))
            if cijferOri == cijferNew:
                print("Ze komen overeen!")
            elif cijferOri < cijferNew:
                print("Je heb het cijfer verbeterd")
            else:
                print("Je hebt het slechter gedaan")
            print(40*"=")
                                            
                
#aanroep van main
main()
