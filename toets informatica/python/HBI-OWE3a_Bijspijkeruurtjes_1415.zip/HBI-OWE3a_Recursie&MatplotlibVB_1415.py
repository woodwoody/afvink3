# Auteur: Esther Kok
# Datum: 18-03-2015
# Histogram en recursie voorbeelden
# LET OP!!! DIT IS IN PYTHON 2.7.9 (want met Python(x,y) heb ik Matplotlib)
# WIL JE DIT DRAAIEN IN 3.4, PAS DAN DE PRINTS AAN!

# imports
import matplotlib.pyplot as plt
import random as rm
import sys

# Onze betrouwbare main functie
def main():
    # Kies een van deze seqs om mee te testen
    seq = 'blablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablablabla'
    seq = 'atgcatgcatgcatgcatgcatgcatgcatgcatgcatgcatgc'
    plotData = [rm.randint(0,100) for i in range(1,100)]
    plotData.sort()
    plotter(plotData)
    
    # We zetten de recursielimiet op de len(seq) + 7, omdat dit de maat van de stack is
    # waar we toegang tot willen en daarna gaan we recursiveren(?)
    sys.setrecursionlimit(len(seq)+7)
    print "IsDNA: ", dnaCheck(seq)

    # We maken nu een random lijst met 100 getallen ergens tussen de 0 en de 100
    # Omdat we net de recursie limiet op len(seq) gezet hadden moeten we deze even resetten
    # En daarna gaan we de recursie opnieuw in
    inputLijst = [rm.randint(0,100) for i in range(0,100)]
    sys.setrecursionlimit(len(inputLijst)+7)
    print "Inputlijst:", inputLijst
    print "Gesorteerd:", sorteer(inputLijst)

    # We gaan nu de fibbo functie aanroepen
    # Dus weer de recursion limit resetten
    print "We gaan een fibbonaci reeks maken!"
    x = input("Eerste getal: ")                             # eerste getal
    y = input("Tweede getal: ")                             # tweede getal
    limiet = input("Hoe lang wil je dat de reeks wordt? ")  # hoe lang de reeks wordt
    sys.setrecursionlimit((limiet*2) + 7)  # limiet * 2 omdat dit ongeveer de verwachtte lengte van de resultaatlijst op de stack is
    print "Reeks:", fibbo(x, y, limiet)
    
    
# recursieve functie om te berekenen of een sequentie wel echt DNA is
# verwacht een sequentie (x) en een boolean initalisatie waarde (isDNA)
# retourneert een boolean (isDNA) met daarin of de sequentie DNA is of niet.
def dnaCheck(x, isDNA = True):
    nuc = ['a','t','g','c']
    if len(x) > 0:
        if x[0] not in nuc:
            isDNA = False    
        return dnaCheck(x[1:], isDNA)
    return isDNA

# recursieve functie om een lijst te sorteren
# accepteerd een lijst met getallen en initialiseert in eerste instantie met
# een lege lijst als er geen tweede argument meegegeven wordt.
# Kijkt wel element het kleinste is en voegt deze toe aan de nieuwe lijst.
# Verwijderd dit element uit de originele lijst. Als de originele lijst leeg is is hij klaar.
# N.B. Python heeft een aantal hele goede sorteer algoritmen, dus ga er vooral geen zelf schrijven!
# Dit voorbeeld is slechts ter illustratie.
def sorteer(lijst, addset = None):
    if addset is None:
        addset = []
    if len(lijst) ==0:
        return addset
    else:
        x = min(lijst)
        lijst.remove(x)
        addset.append(x)
        return sorteer(lijst, addset)

# recursieve functie die een fibbonaci reeks maakt adhv getal1 en getal2
# herhaling is hoe lang we willen dat de reeks wordt
def fibbo(getal1, getal2, herhaling, i = 0, reeks = None):
    if reeks is None:
        reeks = [getal1, getal2]
    if (herhaling-2) == i:          # herhaling - 2 omdat de eerste twee getallen al bekend zijn (we willen lengte herhaling)
        return reeks
    else:
        getal3 = getal1 + getal2
        reeks.append(getal3)
        return fibbo(getal2, getal3, herhaling, i+1, reeks)
    

# een functie die een histogram plot
# zie http://matplotlib.org/1.3.1/api/pyplot_api.html?highlight=hist#matplotlib.pyplot.hist
# voor meer informatie over de argumenten van hist()
def plotter(data):
    plt.hist(data, 20)
    plt.xlabel("Data bins (20 in total)")
    plt.ylabel("Number of times")
    #plt.show()                         #Zet deze aan en uit om de plot wel of niet te zien
    
# om de boel af te ronden roepen we de main nog even aan
main()
