# Auteur: Esther Kok
# Datum: 25-03-2015
# Classes en dictionary nesting
# Python 3.4 compatible

# imports
import re

# main funnctie
def main():
    seq = "santoheugaoeuxbaoesuthdbasoeihfgseoubioseuithgeonuihxoenmbuix"
    #seq = "blablablablablablablablablablablabla"
    regex1 = input("Gief regex: ")
    gen1 = gen(seq)
    print(gen1.regex(regex))
    gen1.codonSplitter()
    print(gen1.countCodons())
    

class gen:
    def __init__(self, sequence):
        self.seq = sequence
        self.codonList = []
        self.codonDict = {}

    def regex(self, regex):
        p = re.compile(regex)
        m = p.search(self.seq)
        if m is None:
            self.matches = False
        else:
            self.matches = True
        return self.matches

    # vergeet deze even, dit is ter illustratie en om een codonlijst te maken om mee verder te werken
    def codonSplitter(self, sequence = None, codons = None):
        if sequence is None:
            sequence = self.seq
        if codons is None:
            codons = self.codonList
        if len(sequence) < 3:
            return self.codonList
        else:
            codons.append(sequence[0:3])
            return self.codonSplitter(sequence[3:], codons)

    def countCodons(self):
        for item in self.codonList:
            number = self.codonList.count(item)
            self.codonDict.update({item:{}}) # for elke key (item) stop een lege dictionary {} in de value

            # nesting van de dictionary, dus {key:{innerkey:value}}
            for ding in self.codonList:
                if ding == item:
                    self.codonDict.update({item:{ding:number}})
        return self.codonDict
        
    
main()
