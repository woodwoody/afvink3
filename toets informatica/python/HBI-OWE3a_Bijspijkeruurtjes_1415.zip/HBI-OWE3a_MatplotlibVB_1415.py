import random as rdm
import numpy as np
import matplotlib.pyplot as plt

def main():
    gegevens = maakData()
    maakBarPlot(gegevens)
    maakLinePlot(gegevens)
    maakPolyPlot(gegevens)
    plt.show()

def maakData():
    data1 = [rdm.randint(0,10) for _ in range(100)]
    data2 = [rdm.randint(0,100) for _ in range(100)]
    return data1, data2

def maakBarPlot(data):
    data1 = data[0]
    data2 = data[1]
    
    plt.subplot(211)
    plt.bar([i for i in range(len(data1))], data1, color="purple")
    plt.legend('bar1')
    
    plt.subplot(212)
    plt.bar([i for i in range(len(data2))], data2, color="green")
    plt.legend('bar2')

    plt.ylabel("Y axis")
    plt.xlabel("X axis") 
        
main()
