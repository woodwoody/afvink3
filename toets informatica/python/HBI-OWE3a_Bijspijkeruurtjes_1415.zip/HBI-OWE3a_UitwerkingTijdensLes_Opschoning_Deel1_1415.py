# @Description: A script to calculate exam results
# @Author:      Esther Kok
# @Date:        04-03-2015
# @Version:     1.1
#
# Dit is de opgeschoonde versie van het script dat we in de les gemaakt hebben.

#imports
import random

#main functie
def main():
        tentamenKans1 = maakCijferlijst()
        tentamenKans2 = maakCijferlijst()

        # Let op het verschil tussen deze twee prints!
        # De eerste is een string concatenatie (een samenvoeging van strings),
        # dus moet je je lijst naar str() omzetten om ze bij elkaar te kunnen voegen.
        # De tweede geeft meerdere argumenten mee aan print() waardoor hij ze netjes
        # met een spatie van elkaar gescheiden houdt. Omzetten naar str() is dus niet nodig.
        print("De lijst van kans 1 is: " + str(tentamenKans1))
        print("De lijst van kans 2 is:" , tentamenKans2)

        ###
        ## Deze prints hebben we nu niet nodig, maar bestudeer ze om de indexen te achterhalen.
        #print("Het eerste element uit de lijst is: " + str(tentamenKans1[0]))
        #print("Het tweede element uit de lijst is: " + str(tentamenKans1[1]))
        #print("Het rest van de lijst is: " + str(tentamenKans1[2:]))
        #print("Het tweede tot en met het vierde element uit de lijst is: " + str(tentamenKans1[1:4]))
        ###

        print("### Kans 1 ###")
        geslaagdOfGezakt(tentamenKans1)
        print("### Kans 2 ###")
        geslaagdOfGezakt(tentamenKans2)

        vergelijkCijfers(tentamenKans1, tentamenKans2)

#functies
def maakCijferlijst():
	cijferlijst = []
	for i in range(0,10):
		cijferlijst.append(random.randint(0,10))
	return cijferlijst

def geslaagdOfGezakt(lijst):
        for cijfer in lijst:
                print("Dit is het cijfer:",cijfer)
                if cijfer == 10:
                        print("Je heb een super voldoende")
                elif cijfer >= 8:
                        print("Je hebt een goede voldoende")
                elif cijfer > 5:
                        print("Je hebt een voldoende")
                else:
                        print("Je hebt een onvoldoende :(")
                print(40*"=")
        
def vergelijkCijfers(lijst1, lijst2):
        # vergelijk het cijfer in de kans 1 lijst met het cijfer op dezelfde plek in kans 2 lijst.
        for cijfer1 in lijst1:
                if cijfer1 == lijst2[0]:
                        print("Je hebt hetzelfde cijfer.")
                elif cijfer1 < lijst2[0]:
                        print("Je hebt een beter cijfer gehaald! :)")
                else:
                        print("Je hebt het helaas slechter gedaan. :(")
                
def besteVanDeKlas(lijst1, lijst2):
        for cijferOld in lijst1:
                for cijferNew in lijst2:
                        if cijferOld == cijferNew:
                                print("YAY! De cijfers komen overeen! :D")
                                print(40*"=")
                        else:
                                print("Awwww. De cijfers komen niet overeen. :(")
                                print(40*"=")
                

#uitvoeren/aanroepen main
main()
